  run with the following command
  starver SL11d_embed
  cons
  root4star -b -q 'Kpluseff19new.C("testnew19.list")'
