void Kpluseff19new(char *inputlist = "19full.list"){


	gSystem->Load("StRefMultCorr");
	StRefMultCorr* refmultCorrUtil = new StRefMultCorr();


	gSystem->Load("StMiniMcEvent");

	TChain *chain = new TChain("StMiniMcTree");
	
	ifstream i1(inputlist);
	char files[512];
	while(!i1.eof()){
		i1.getline(files,512);
		chain->Add(files);
	}
	
	StMiniMcEvent *minimc = 0;
	chain->SetBranchAddress("StMiniMcEvent",&minimc);

	long ev = chain->GetEntries();
	cout<<ev<<" events"<<endl;

	float kmass = 0.493677;

	TH1F *histR[11];	  
	TH1F *histMC[11];	  
	TH1F *histE[11];	  
	TH1F *hfitpts[11];	  
						  
	TH1F *hgeantid[11];   
	TH1F *hgeantidmc[11]; 
	TH2F *hgeantid2d[11]; 
	TH1D *hnpossible[11]; 
						  
	TH3F *histR3D[11];	  
	TH3F *histMC3D[11];   
	TH3F *histE3D[11];	  
						  
	TH2F *histRy[11];	  
	TH2F *histMCy[11];	  
	TH2F *histEy[11];	  
						  
	TH3F *histRyp[11];	  
	TH3F *histMCyp[11];   
	TH3F *histEyp[11];	  
						  
	TH2F *histpx[11];	  
	TH2F *histpy[11];	  
	TH2F *histpz[11];	  
						  
	TH2F *histpt[11];	  
	TH2F *histeta[11];	  
	TH2F *histphi[11];	  
						  
	TH2F *histpxi[11];	  
	TH2F *histpyi[11];	  
	TH2F *histpzi[11];	  

    TH1F *histcen = new TH1F("centrality","centrality",10,0,10);
    TH1F *hrefmult = new TH1F("refmult","refmult",800,0,800);	
    TH1F *hrefmultcorr = new TH1F("refmultcorr","refmultcorr",800,0,800);
    TH1F *hrefmultcorrweight = new TH1F("refmultcorrweight","refmultcorrweight",800,0,800);	

	TH2F *hptvsphiMC = new TH2F("ptvsphiMC", "pt vs phi MC", 400, 0, 10, 400, -5., 5.);
	TH2F *hptvsetaMC = new TH2F("ptvsetaMC", "pt vs eta MC", 400, 0, 10, 200, -2., 2.);
	TH2F *hptvsyMC = new TH2F("ptvsyMC", "pt vs rapidity MC", 400, 0, 10, 200, -2., 2.);
	TH2F *hetavsphiMC = new TH2F("etavsphiMC", "eta vs phi MC", 200, -2, 2, 400, -5., 5.);	
	TH2F *hptvsphiRC = new TH2F("ptvsphiRC", "pt vs phi RC", 400, 0, 10, 400, -5., 5.);
	TH2F *hptvsetaRC = new TH2F("ptvsetaRC", "pt vs eta RC", 400, 0, 10, 200, -2., 2.);
	TH2F *hptvsyRC = new TH2F("ptvsyRC", "pt vs rapidity RC", 400, 0, 10, 200, -2., 2.);
	TH2F *hetavsphiRC = new TH2F("etavsphiRC", "eta vs phi RC", 200, -2, 2, 400, -5., 5.);

    TH2D *hKplusEnergyLossvspt = new TH2D("kplusEnergyLossvspt", "kplus rcpt-mcpt vs rcpt", 400, 0, 8, 2000, -1.0, 1.0);
    TH2D *hKplusEnergyLossvsp = new TH2D("kplusEnergyLossvsp", "kplus rcpt-mcpt vs rcp", 400, 0, 8, 2000, -1.0, 1.0);
    TH2D *hKplusdeltainvptvspt = new TH2D("kplusdeltainvptvspt", "kplus 1/rcpt-1/mcpt vs rcpt", 400, 0, 8, 4000, -2.0, 2.0);	
    TH2D *hKplusdeltainvptvsp = new TH2D("kplusdeltainvptvsp", "kplus 1/rcpt-1/mcpt vs rcp", 400, 0, 8, 4000, -2.0, 2.0);
		
    char name[256], title[256];
	for(int k=0; k<11; k++)
	{
    sprintf(name,"histR_cen_%d", k);
	sprintf(title,"reco_cen_%d", k);
	histR[k] = new TH1F(name,title,160,0,8);
	histR[k]->Sumw2();	
    sprintf(name,"histMC_cen_%d", k);
	sprintf(title,"mc_cen_%d", k);	
	histMC[k] = new TH1F(name,title,160,0,8);	
	histMC[k]->Sumw2();
	sprintf(name,"histE_cen_%d", k);
	sprintf(title,"efficiency_cen_%d", k);	
	histE[k] = new TH1F(name,title,160,0,8);	
	histE[k]->Sumw2();
    sprintf(name,"histftpts_cen_%d", k);
	sprintf(title,"nfitpts_cen_%d", k);
    hfitpts[k] = new TH1F(name,title,50,0,50);
	hfitpts[k]->Sumw2();
    sprintf(name,"hgeantid_cen_%d", k);
	sprintf(title,"GeantID_cen_%d", k);
	hgeantid[k] = new TH1F(name, title, 50, 0, 50);
	hgeantid[k]->Sumw2();
    sprintf(name,"hgeantidmc_cen_%d", k);
	sprintf(title,"GeantIDmc_cen_%d", k);
	hgeantidmc[k] = new TH1F(name, title, 50, 0, 50);
	hgeantidmc[k]->Sumw2();
    sprintf(name,"hgeantid2D_cen_%d", k);
	sprintf(title,"GeantID2D: mc vs recons_cen_%d", k);
	hgeantid2d[k] = new TH2F(name, title, 50, 0, 50, 50, 0, 50);
	hgeantid2d[k]->Sumw2();
    sprintf(name,"hnpossible_cen_%d", k);
	sprintf(title,"hnpossible_cen_%d", k);
	hnpossible[k] = new TH1D(name, title, 50, 0, 50);
	hnpossible[k]->Sumw2();
	sprintf(name,"histR3D_cen_%d", k);
	sprintf(title,"reco_cen_%d", k);
	histR3D [k] = new TH3F(name,title,160,-8,8,160,-8,8,160,-8,8);
	histR3D[k]->Sumw2();
	sprintf(name,"histMC3D_cen_%d", k);
	sprintf(title,"mc_cen_%d", k);
	histMC3D[k] = new TH3F(name,title,160,-8,8,160,-8,8,160,-8,8);	
	histMC3D[k]->Sumw2();
	sprintf(name,"histE3D_cen_%d", k);
	sprintf(title,"efficiency_cen_%d", k);
	histE3D[k] = new TH3F(name,title,160,-8,8,160,-8,8,160,-8,8);	
	histE3D[k]->Sumw2();
	sprintf(name,"RCpteta_cen_%d", k);
	sprintf(title,"RC_ptvsetareco_cen_%d", k);	
	histRy[k] = new TH2F(name,title,160,0,8,24,-1.2,1.2);
	histRy[k]->Sumw2();	
	sprintf(name,"MCpteta_cen_%d", k);
	sprintf(title,"MC_ptvseta_%d", k);
	histMCy[k] = new TH2F(name,title,160,0,8,24,-1.2,1.2);	
	histMCy[k]->Sumw2();
	sprintf(name,"histEy_cen_%d", k);
	sprintf(title,"efficiency_cen_%d", k);
	histEy[k] = new TH2F(name,title,160,0,8,24,-1.2,1.2);	
	histEy[k]->Sumw2();
	sprintf(name,"histRyp_cen_%d", k);
	sprintf(title,"reco_cen_%d", k);
	histRyp[k] = new TH3F(name,title,80,0,8,20,-1,1,60,-3.14159265,3.14159265);
	histRyp[k]->Sumw2();	
	sprintf(name,"histMCyp_cen_%d", k);
	sprintf(title,"mc_cen_%d", k);	
	histMCyp[k] = new TH3F(name,title,80,0,8,20,-1,1,60,-3.14159265,3.14159265);	
	histMCyp[k]->Sumw2();
	sprintf(name,"histEyp_cen_%d", k);
	sprintf(title,"efficiency_cen_%d", k);		
	histEyp[k] = new TH3F(name,title,80,0,8,20,-1,1,60,-3.14159265,3.14159265);	
	histEyp[k]->Sumw2();

	sprintf(name,"histpx_cen_%d", k);
	sprintf(title,"MC vs reco-MC px_cen_%d", k);	
	histpx[k] = new TH2F(name,title,160,-8,8,500,-5,5);
	sprintf(name,"histpy_cen_%d", k);
	sprintf(title,"MC vs reco-MC py_cen_%d", k);	
	histpy[k] = new TH2F(name,title,160,-8,8,500,-5,5);
	sprintf(name,"histpz_cen_%d", k);
	sprintf(title,"MC vs reco-MC pz_cen_%d", k);
	histpz[k] = new TH2F(name,title,160,-8,8,500,-5,5);
	
	sprintf(name,"histpt_cen_%d", k);
	sprintf(title,"MC vs reco-MC pt_cen_%d", k);
	histpt[k] = new TH2F(name,title,160,0,8,1500,-8,8);
	sprintf(name,"histeta_cen_%d", k);
	sprintf(title,"MC vs reco-MC eta_cen_%d", k);
	histeta[k] = new TH2F(name,title,200,-1.2,1.2,500,-0.1,0.1);
	sprintf(name,"histphi_cen_%d", k);
	sprintf(title,"MC vs reco-MC phi_cen_%d", k);
	histphi[k] = new TH2F(name,title,100,-3.14159265,3.14159265,500,-0.2,0.2);
	sprintf(name,"histpxi_cen_%d", k);
	sprintf(title,"MC vs 1/reco-1/MC px_cen_%d", k);	
	histpxi[k] = new TH2F(name,title,160,-8,8,500,-5,5);
	sprintf(name,"histpyi_cen_%d", k);
	sprintf(title,"MC vs 1/reco-1/MC py_cen_%d", k);	
	histpyi[k] = new TH2F(name,title,160,-8,8,500,-5,5);
	sprintf(name,"histpzi_cen_%d", k);
	sprintf(title,"MC vs 1/reco-1/MC pz_cen_%d", k);
	histpzi[k] = new TH2F(name,title,160,-8,8,500,-5,5);
	
	histMC[k]->SetLineColor(4);	
	}


	TH1F *VertexZ = new TH1F("VertexZ","VertexZ",400,-200.,200.);
	TH1F *VertexZweight = new TH1F("VertexZweight","VertexZ with event weight",400,-200.,200.);	
	TH2F *VertexZvscen = new TH2F("VertexZvscen","VertexZvscen", 10, 0, 10, 400,-200.,200.);
	TH1F *dvx = new TH1F("DeltaVertexX","VertexX(RC-MC)",200,-10.,10.);
	TH1F *dvy = new TH1F("DeltaVertexY","VertexY(RC-MC)",200,-10.,10.);	
	TH1F *dvz = new TH1F("DeltaVertexZ","VertexZ(RC-MC)",200,-10.,10.);	

	int runnumber = 12111032;
	refmultCorrUtil->init(runnumber);
	 // Print all parameters
    //  - Don't print centrality and correction parameters without any option string (default)
    refmultCorrUtil->print("Alex");

    // Obtain begin and end run number from energy and year
    cout << "Run " << refmultCorrUtil->getBeginRun(19.6, 2011) << " - " << refmultCorrUtil->getEndRun(19.6, 2011) << endl;

	bool badrunpointer = refmultCorrUtil->isBadRun(runnumber);
	int nbadevts = 0;

	cout<<"run	12114035 is bad?	"<<refmultCorrUtil->isBadRun(12114035)<<endl;

	for(long i=0;i<ev;i++) {    
				
		if(i%1000==0) cout<<"Event "<<i<<endl;
		
		chain->GetEntry(i);

		if(runnumber != minimc->runId())
		{runnumber = minimc->runId();
		 refmultCorrUtil->init(runnumber);
		 badrunpointer = refmultCorrUtil->isBadRun(runnumber);
		}
		if(badrunpointer) {cout<<"run	"<<minimc->runId()<<"	is bad run, ignore!"; nbadevts++; continue;}
		
		float vx=minimc->vertexX();
		float vy=minimc->vertexY();
		float vz = minimc->vertexZ();
		if( (vx<+1.0e-5 && vx>-1.0e-5) && (vy<+1.0e-5 && vy>-1.0e-5) && (vz<+1.0e-5 && vz>-1.0e-5)) continue;
		double vzin = (double)vz;
		float mcvx=minimc->mcVertexX();
		float mcvy=minimc->mcVertexY();
		float mcvz = minimc->mcVertexZ();		
		dvx->Fill(vx-mcvx);
		dvy->Fill(vy-mcvy);
		dvz->Fill(vz-mcvz);
		if(sqrt(vx*vx+vy*vy)>=2) continue;
		
		int refmult = minimc->nUncorrectedPrimaries();
		UShort_t refmultin = (UShort_t) refmult;		
		double zdcCoincidenceRate = 0;
		refmultCorrUtil->initEvent(refmultin, vzin, zdcCoincidenceRate);

		const Int_t cent16 = refmultCorrUtil->getCentralityBin16();
        const Int_t cent9  = refmultCorrUtil->getCentralityBin9()+1;

       // cout<<"cen16	"<<cent16<<"	cen9	"<<cent9<<endl;

  		// Re-weighting corrections for peripheral bins
  		const Double_t reweight = refmultCorrUtil->getWeight() ;

  		//cout<<"reweight	"<<reweight<<endl;

  		//----------------------------------------------------------------------------------------------------
  		// Not really necessary for your study but if you want to see the corrected refmult distribution
  		// Corrected refmult (z-vertex dependent correction)
  		//  NOTE: type should be double or float, not integer
  		const Double_t refmultCor = refmultCorrUtil->getRefMultCorr() ;
  		//cout<<"refmult	"<<refmult<<"	refmultcorr		"<<refmultCor<<endl;
 		
		//int cent = getCentrality(refmult);	
		int cent = getCentrality(cent9);
		VertexZvscen->Fill(cent, vz);
		if(cent>0){VertexZ->Fill(vz); VertexZweight->Fill(vz,reweight);}
		hrefmult->Fill(refmult);
		hrefmultcorr->Fill(refmultCor);
		hrefmultcorrweight->Fill(refmultCor, reweight);		
		if(fabs(vz) >= 70) continue;		
		histcen->Fill(cent, reweight);
		//if(minimc->nUncorrectedPrimaries()<=106) continue;  //0-20%
		int numRe = minimc->nMatchedPair();
		int numMC = minimc->nMcTrack();

		//cout<<"numRe	"<<numRe<<endl;

		for(int j=0;j<numRe;j++){
			StMiniMcPair *retrack = (StMiniMcPair*)minimc->tracks(1)->UncheckedAt(j);
	//		cout<<"Global DCA "<<retrack->dcaGl()<<endl;
	//        cout<<retrack->geantId()<<endl;
	       hgeantid[cent]->Fill(retrack->geantId(),reweight);
	       hnpossible[cent]->Fill(retrack->nPossiblePts()*1.0,reweight);
	        double nfitovermax = ((double)retrack->fitPts())/((double)retrack->nPossiblePts());
			if(retrack->geantId()==11 && !retrack->parentGeantId() && retrack->commonHits() > 5 && retrack->fitPts() >= 15 && retrack->fitPts() < 50 && fabs(retrack->dcaGl()) < 3 && fabs(retrack->ptPr()) > 1e-6 && fabs(retrack->phiPr()) > 1e-6 && nfitovermax>0.52 && nfitovermax<1.02){
                hfitpts[cent]->Fill(retrack->fitPts(),reweight);
				histpx[cent]->Fill(retrack->pxMc(),retrack->pxPr()-retrack->pxMc(),reweight); 
				histpy[cent]->Fill(retrack->pyMc(),retrack->pyPr()-retrack->pyMc(),reweight); 
				histpz[cent]->Fill(retrack->pzMc(),retrack->pzPr()-retrack->pzMc(),reweight);
				histpt[cent]->Fill(retrack->ptMc(),retrack->ptPr()-retrack->ptMc(),reweight); 
				histeta[cent]->Fill(retrack->etaMc(),retrack->etaPr()-retrack->etaMc(),reweight); 
				histphi[cent]->Fill(retrack->phiMc(),retrack->phiPr()-retrack->phiMc(),reweight);
				if( (retrack->pxPr()&&retrack->pxMc())) histpxi[cent]->Fill(retrack->pxMc(),(1.0/retrack->pxPr())-(1.0/retrack->pxMc()),reweight); 
				if( (retrack->pyPr()&&retrack->pyMc())) histpyi[cent]->Fill(retrack->pyMc(),(1.0/retrack->pyPr())-(1.0/retrack->pyMc()),reweight); 
				if( (retrack->pzPr()&&retrack->pzMc())) histpzi[cent]->Fill(retrack->pzMc(),(1.0/retrack->pzPr())-(1.0/retrack->pzMc()),reweight);				

				//if(fabs(retrack->etaPr()) < 1.2 && retrack->flag()>0 && retrack->flag()<=1000 ){				
                if(fabs(retrack->etaPr()) < 1.2 ){
				    histR[cent]->Fill(retrack->ptPr(),reweight);
					TLorentzVector kaonRC(0,0,0,0);
				    kaonRC.SetXYZM(retrack->pxPr(), retrack->pyPr(), retrack->pzPr(), kmass);
				    hptvsetaRC->Fill(retrack->ptPr(), retrack->etaPr(),reweight);
					hptvsphiRC->Fill(retrack->ptPr(), retrack->phiPr(),reweight);
					hetavsphiRC->Fill(retrack->etaPr(), retrack->phiPr(),reweight);
                	hptvsyRC->Fill(retrack->ptPr(), kaonRC.Rapidity(),reweight);
					if(fabs(retrack->etaPr()) < 1.0){histE[cent]->Fill(retrack->ptPr(),reweight);}
									
					//histR3D[cent]->Fill(retrack->pxPr(),retrack->pyPr(),retrack->pzPr());
					//histE3D[cent]->Fill(retrack->pxPr(),retrack->pyPr(),retrack->pzPr());
					histRy[cent]->Fill(retrack->ptPr(),retrack->etaPr(),reweight);
					histEy[cent]->Fill(retrack->ptPr(),retrack->etaPr(),reweight);
					
					histRyp[cent]->Fill(retrack->ptPr(),retrack->etaPr(),retrack->phiPr(),reweight);
					histEyp[cent]->Fill(retrack->ptPr(),retrack->etaPr(),retrack->phiPr(),reweight);
                }

				if(fabs(retrack->etaPr()) < 1.0 ){
                double prc = sqrt(retrack->pxPr()*retrack->pxPr()+retrack->pyPr()*retrack->pyPr()+retrack->pzPr()*retrack->pzPr());
				double pmc = sqrt(retrack->pxMc()*retrack->pxMc()+retrack->pyMc()*retrack->pyMc()+retrack->pzMc()*retrack->pzMc());
                hKplusEnergyLossvsp->Fill(prc, retrack->ptPr()-retrack->ptMc(),reweight);
				hKplusEnergyLossvspt->Fill(retrack->ptPr(), retrack->ptPr()-retrack->ptMc(),reweight);
				if(retrack->ptPr()>0 && retrack->ptMc()>0)
					{hKplusdeltainvptvsp->Fill(prc, 1.0/retrack->ptPr()-1.0/retrack->ptMc(),reweight);
					hKplusdeltainvptvspt->Fill(retrack->ptPr(), 1.0/retrack->ptPr()-1.0/retrack->ptMc(),reweight);
					}
				}
								
			}
		
		}
		
		
		for(int j=0;j<numMC;j++){			
			StTinyMcTrack *mctrack = (StTinyMcTrack*)minimc->tracks(0)->UncheckedAt(j);			
			if(mctrack->geantId()==11 && !mctrack->parentGeantId() && fabs(mctrack->etaMc()) < 1.2 && mctrack->ptMc() > 0.0){
				TLorentzVector kaonMC(0,0,0,0);
				hgeantidmc[cent]->Fill(mctrack->geantId(),reweight);
				kaonMC.SetXYZM(mctrack->pxMc(), mctrack->pyMc(), mctrack->pzMc(), kmass);
				hptvsetaMC->Fill(mctrack->ptMc(), mctrack->etaMc(),reweight);
				hptvsphiMC->Fill(mctrack->ptMc(), mctrack->phiMc(),reweight);
				hetavsphiMC->Fill(mctrack->etaMc(), mctrack->phiMc(),reweight);
                hptvsyMC->Fill(mctrack->ptMc(), kaonMC.Rapidity(),reweight);			
				
                if(fabs(mctrack->etaMc())<1.0){	histMC[cent]->Fill(mctrack->ptMc(),reweight);}
				//histMC3D[cent]->Fill(mctrack->pxMc(),mctrack->pyMc(),mctrack->pzMc());
				histMCy[cent]->Fill(mctrack->ptMc(),mctrack->etaMc(),reweight);
				histMCyp[cent]->Fill(mctrack->ptMc(),mctrack->etaMc(),mctrack->phiMc(),reweight);

			}
		}
		
        if(numMC==1&&numRe==1){
		  for(int j=0;j<numMC;j++){
		  	StTinyMcTrack *mctrack = (StTinyMcTrack*)minimc->tracks(0)->UncheckedAt(j);
			for(int k=0;k<numRe;k++)
			{StMiniMcPair *retrack = (StMiniMcPair*)minimc->tracks(1)->UncheckedAt(k);
			hgeantid2d[cent]->Fill(mctrack->geantId(),retrack->geantId(),reweight);}
			}
        }
	}

	for(int k=0; k<11; k++){
	histE[k]->Divide(histMC[k]);
	//histE3D->Divide(histMC3D);
	histEy[k]->Divide(histMCy[k]);
	histEyp[k]->Divide(histMCyp[k]);
	}
 
    cout<<"total "<<nbadevts<<" events from bad runs in total "<<ev<<" events"<<endl;
		
    char output[2560];
	sprintf(output, "%snewwithelossrefmultweighteta1.0_vz70.root", inputlist);
	
	TFile f1(output,"RECREATE");
	for(int k=0; k<11; k++){
	histMC[k]->Write();
	histE[k]->Write();	
	hfitpts[k]->Write();
	hgeantid[k]->Write();
	hgeantidmc[k]->Write();
	hgeantid2d[k]->Write();
	hnpossible[k]->Write();
	histR[k]->Write();	
	histMCy[k]->Write();
	histEy[k]->Write();	
	histRy[k]->Write();	
	histMCyp[k]->Write();
	histEyp[k]->Write();	
	histRyp[k]->Write();
	//histMC3D[k]->Write();
	//histE3D[k]->Write();	
	//histR3D[k]->Write();	
	histpx[k]->Write();
	histpy[k]->Write();
	histpz[k]->Write();	
	histpxi[k]->Write();
	histpyi[k]->Write();
	histpzi[k]->Write();
	histpt[k]->Write();
	histeta[k]->Write();
	histphi[k]->Write();
	}
	VertexZ->Write();
	VertexZweight->Write();	
	VertexZvscen->Write();
	dvx->Write();
	dvy->Write();
	dvz->Write();
	histcen->Write();
	hrefmult->Write();
	hrefmultcorr->Write();	
    hrefmultcorrweight->Write();
	hptvsetaMC->Write();
	hptvsphiMC->Write();
	hptvsyMC->Write();
	hetavsphiMC->Write();
    hptvsetaRC->Write();
	hptvsphiRC->Write();
	hptvsyRC->Write();
	hetavsphiRC->Write();	
	hKplusEnergyLossvspt->Write();
	hKplusEnergyLossvsp->Write();
	hKplusdeltainvptvspt->Write();	
	hKplusdeltainvptvsp->Write();	
	f1.Close();

}

/*int getCentrality(int grefMult)
{
   

	if      (grefMult <= 8)   { return 0; }
	//else if (grefMult <= 15)   { return 1; }
	//else if (grefMult <= 28)   { return 2; }
	else if (grefMult <= 50) {return 1;}
	else if (grefMult <= 100)   { return 2; }
	else if (grefMult <= 160)  { return 3; }
	else if (grefMult <= 220)  { return 4; }
	else                      { return 5; }

}	
*/
int getCentrality(int gcent9)
{
   
	if      (gcent9 <= 0)   { return 0; }
	//else if (grefMult <= 15)   { return 1; }
	//else if (grefMult <= 28)   { return 2; }
	else if (gcent9 <= 2) {return 1;}
	else if (gcent9 <= 4)   { return 2; }
	else if (gcent9 <= 5)  { return 3; }
	else if (gcent9 <= 6)  { return 4; }
    else if (gcent9 <= 7)  { return 5; }
	else                      { return 6; }

}


